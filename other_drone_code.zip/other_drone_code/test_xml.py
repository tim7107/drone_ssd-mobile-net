from pascal_voc_writer import Writer as PascalWriter
import cv2
import numpy as np
import os

def data(temp):
    frame_.append(temp[0])
    x_center.append(temp[1])
    y_center.append(temp[2])
    
def global_img_num_jpg(num):
    if num<10:
        return '00000'+str(num)+'.jpg'
    elif 10<=num<100:
        return '0000'+str(num)+'.jpg'
    elif 100<=num<1000:
        return '000'+str(num)+'.jpg'
    elif 1000<=num<10000:
        return '00'+str(num)+'.jpg'
    else:
        return '0'+str(num)+'.jpg'
    
def global_img_num_xml(num):
    if num<10:
        return '00000'+str(num)+'.xml'
    elif 10<=num<100:
        return '0000'+str(num)+'.xml'
    elif 100<=num<1000:
        return '000'+str(num)+'.xml'
    elif 1000<=num<10000:
        return '00'+str(num)+'.xml'
    else:
        return '0'+str(num)+'.xml'
    
def determine_radius(cur_v):
    if cur_v == 0 :
        return 40
    elif 1<=cur_v<=7 or cur_v==10 or cur_v==17:
        return 30
    elif cur_v==11:
        return 20
    elif cur_v==8 or cur_v==14 :
        return 10
    else:
        return 15   

# def determine_img_size(cur_v):
    # if cur_v == 10 or cur_v == 17:
        # return 3840,2160,3
    # elif cur_v == 11 or cur_v ==20:
        # return 1440,1080,3
    # else:
        # return 1920,1080,3
#----init setting----#
cur_v = 0
v = 'v' + str(cur_v)
video = 'video' + str(cur_v)
first_img_frame = 3000*cur_v
detection_pth = '/home/tim7107/drone/drone-tracking-datasets/dataset1/detections/cam0.txt'
drone_300_300_pth = os.path.join('/mnt/usb/drone_300_300',video)
bbox_temp = 'v' + str(cur_v) + '_bbox.npy'
bbox_npy_pth = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/bbox_300_300/',bbox_temp)
v_img_pth = []
radius = determine_radius(cur_v)
frame_ = []
x_center = []
y_center = []

# xml
database = 'The VOC2007 Database'
annotation = 'PASCAL VOC2007'
image = 'flickr'
width,height,depth = 300,300,3
segmented = 0
object_name = 'person'
object_pose = 'right'
object_truncated = 0
object_difficult = 0
bbox = np.load(bbox_npy_pth)
Annotation_pth = '/home/tim7107/drone/VOCdevkit_drone_ver/VOC2007/Annotations'

#--- read x,y center ---# 
f = open(detection_pth, 'r')
lines = f.readlines() 
for line in lines:
    temp =[]
    for word in line.split(): 
        temp.append(int(float(word)))
    data(temp)
f.close()  
frame_ = np.array(frame_)
x_center = np.array(x_center)
y_center = np.array(y_center)

#---file name---#
for i in range(3000):
    cur_i = first_img_frame + i
    img_num = global_img_num_jpg(cur_i)
    v_img_pth.append(img_num)

i = 1
pascalWriter = PascalWriter('/home/tim7107/data/VOCdevkit/VOC2012/JPEGImages/2007_000027.jpg',486 , 500)
pascalWriter.addObject(object_name,bbox[i][0],bbox[i][1],bbox[i][2],bbox[i][3])
pascalWriter.save('/home/tim7107/drone/VOCdevkit_drone_ver/VOC2007/Annotations/2007_000027.xml')