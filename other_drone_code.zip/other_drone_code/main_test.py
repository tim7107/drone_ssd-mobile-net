import numpy as np

def global_img_num(num):
    if num<10:
        return '00000'+str(num)
    elif 10<=num<100:
        return '0000'+str(num)
    elif 100<=num<1000:
        return '000'+str(num)
    elif 1000<=num<10000:
        return '00'+str(num)
    else:
        return '0'+str(num)

def determine(i,s):   
    return s+' '+ '1' + '\n'

# f = open('/mnt/usb/VOCdevkit_drone_ver/VOC2007/ImageSets/Main/train_train.txt', 'w')
f = open('/home/tim7107/pascal_drone/VOCdevkit/train/ImageSets/Main/drone_trainval.txt', 'w')
f1 = open('/home/tim7107/pascal_drone/VOCdevkit/train/ImageSets/Main/drone_train.txt', 'w')
f2 = open('/home/tim7107/pascal_drone/VOCdevkit/train/ImageSets/Main/drone_val.txt','w')
#---dataset1---#
for i in range(1000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(3000,4000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f1.write(temp)    
for i in range(6000,7000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f2.write(temp)  
    
#---dataset2---#
for i in range(12000,13000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(15000,16000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f1.write(temp)    
for i in range(18000,19000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f2.write(temp) 

#---dataset3---#
for i in range(24000,25000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(27000,28000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f1.write(temp)    
for i in range(30000,31000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f1.write(temp) 
for i in range(33000,34000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(36000,37000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f2.write(temp)    

#---dataset4---#
for i in range(42000,43000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(45000,46000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(48000,49000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f1.write(temp)    
for i in range(51000,52000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f1.write(temp) 
for i in range(54000,55000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(57000,58000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)   
    f2.write(temp) 

f.close()
f1.close()
f2.close()