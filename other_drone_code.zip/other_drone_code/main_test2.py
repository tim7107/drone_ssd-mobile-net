import numpy as np

def global_img_num(num):
    if num<10:
        return '00000'+str(num)+ '\n'
    elif 10<=num<100:
        return '0000'+str(num)+ '\n'
    elif 100<=num<1000:
        return '000'+str(num)+ '\n'
    elif 1000<=num<10000:
        return '00'+str(num)+ '\n'
    else:
        return '0'+str(num)+ '\n'

def determine(i,s):   
    return s+' '+ '1' + '\n'

# f = open('/mnt/usb/VOCdevkit_drone_ver/VOC2007/ImageSets/Main/train_train.txt', 'w')
f = open('/home/tim7107/pascal_drone/VOCdevkit/test/ImageSets/Main/test.txt', 'w')

for i in range(9000,10000):
    temp = global_img_num(i)
    # temp = determine(i,temp)
    f.write(temp)
for i in range(21000,22000):
    temp = global_img_num(i)
    # temp = determine(i,temp)
    f.write(temp)    
for i in range(39000,40000):
    temp = global_img_num(i)
    # temp = determine(i,temp)
    f.write(temp)   
for i in range(60000,61000):
    temp = global_img_num(i)
    # temp = determine(i,temp)
    f.write(temp)      
f.close()
