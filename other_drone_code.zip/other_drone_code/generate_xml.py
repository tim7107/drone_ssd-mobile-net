from pascal_voc_writer import Writer as PascalWriter
import cv2
import numpy as np
import os

def data(temp):
    frame_.append(temp[0])
    x_center.append(temp[1])
    y_center.append(temp[2])
    
def global_img_num_jpg(num):
    if num<10:
        return '00000'+str(num)+'.jpg'
    elif 10<=num<100:
        return '0000'+str(num)+'.jpg'
    elif 100<=num<1000:
        return '000'+str(num)+'.jpg'
    elif 1000<=num<10000:
        return '00'+str(num)+'.jpg'
    else:
        return '0'+str(num)+'.jpg'
    
def global_img_num_xml(num):
    if num<10:
        return '00000'+str(num)+'.xml'
    elif 10<=num<100:
        return '0000'+str(num)+'.xml'
    elif 100<=num<1000:
        return '000'+str(num)+'.xml'
    elif 1000<=num<10000:
        return '00'+str(num)+'.xml'
    else:
        return '0'+str(num)+'.xml'
    
def determine_radius(cur_v):
    if cur_v == 0 :
        return 40
    elif 1<=cur_v<=7 or cur_v==10 or cur_v==17:
        return 30
    elif cur_v==11:
        return 20
    elif cur_v==8 or cur_v==14 :
        return 10
    else:
        return 15   

# def determine_img_size(cur_v):
    # if cur_v == 10 or cur_v == 17:
        # return 3840,2160,3
    # elif cur_v == 11 or cur_v ==20:
        # return 1440,1080,3
    # else:
        # return 1920,1080,3
#----init setting----#
cur_v = 20
v = 'v' + str(cur_v)
video = 'video' + str(cur_v)
first_img_frame = 3000*cur_v
# detection_pth = '/home/tim7107/drone/drone-tracking-datasets/dataset1/detections/cam0.txt'
# drone_300_300_pth = os.path.join('/mnt/usb/drone_300_300',video)
drone_300_300_pth = '/mnt/usb/VOCdevkit_drone_ver/VOC2007/JPEGImage'
bbox_temp = 'v' + str(cur_v) + '_bbox.npy'
bbox_npy_pth = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/bbox_300_300/',bbox_temp)
v_img_pth = []
radius = determine_radius(cur_v)
frame_ = []
x_center = []
y_center = []

# xml
database = 'The VOC2007 Database'
annotation = 'PASCAL VOC2007'
image = 'flickr'
width,height,depth = 300,300,3
segmented = 0
object_name = 'drone'
object_pose = 'right'
object_truncated = 0
object_difficult = 0
bbox = np.load(bbox_npy_pth)
Annotation_pth = '/home/tim7107/pascal_drone/VOCdevkit/test/Annotations/'

# x=3000 - 3000
# img = cv2.imread('/mnt/usb/VOCdevkit_drone_ver/VOC2007/JPEGImage/003000.jpg')
# cv2.rectangle(img,(bbox[x][0],bbox[x][1]),(bbox[x][2],bbox[x][3]),(0,255,0),3)
# cv2.imshow('frame',img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

#--- read x,y center ---# 
# f = open(detection_pth, 'r')
# lines = f.readlines() 
# for line in lines:
    # temp =[]
    # for word in line.split(): 
        # temp.append(int(float(word)))
    # data(temp)
# f.close()  
# frame_ = np.array(frame_)
# x_center = np.array(x_center)
# y_center = np.array(y_center)

#---file name---#
for i in range(1000):
    cur_i = first_img_frame + i
    img_num = global_img_num_jpg(cur_i)
    v_img_pth.append(img_num)

#---start generate xml---#
for i in range(1000):
    pascalWriter = PascalWriter(os.path.join(drone_300_300_pth,v_img_pth[i]), width, height)
    pascalWriter.addObject(object_name,bbox[i][0],bbox[i][1],bbox[i][2],bbox[i][3])
    pascalWriter.save(os.path.join(Annotation_pth,global_img_num_xml(first_img_frame+i)))
# for i in range(2600,3000):
    # pascalWriter = PascalWriter(os.path.join(drone_300_300_pth,v_img_pth[i]), width, height)
    # pascalWriter.save(os.path.join(Annotation_pth,global_img_num_xml(first_img_frame+i)))