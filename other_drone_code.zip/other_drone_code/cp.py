import numpy as np

def global_img_num(num):
    if num<10:
        return '00000'+str(num)+'.jpg '
    elif 10<=num<100:
        return '0000'+str(num)+'.jpg '
    elif 100<=num<1000:
        return '000'+str(num)+'.jpg '
    elif 1000<=num<10000:
        return '00'+str(num)+'.jpg '
    else:
        return '0'+str(num)+'.jpg '

cur_v = 20
first_img_frame = 3000*cur_v
v_temp = 'video'+str(cur_v)+'/'
f = open('/home/tim7107/drone/cp.txt', 'w')

for i in range(1000):
    cur_i = first_img_frame + i
    temp = global_img_num(cur_i)
    temp0 = 'sudo cp /mnt/usb/drone_300_300/' + v_temp + temp
    text = temp0+'/home/tim7107/pascal_drone/VOCdevkit/test/JPEGImages/'+'\n'
    f.write(text)
f.close()