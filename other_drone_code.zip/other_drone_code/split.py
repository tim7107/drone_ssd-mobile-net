import numpy as np

def global_img_num(num):
    if num<10:
        return '00000'+str(num)
    elif 10<=num<100:
        return '0000'+str(num)
    elif 100<=num<1000:
        return '000'+str(num)
    elif 1000<=num<10000:
        return '00'+str(num)
    else:
        return '0'+str(num)

def determine(i,s):
    if 2600<=i<=2999 or 5600<=i<=5999 or 8600<=i<=8999 or 14600<=i<=14999 or 17600<=i<=17999 or 20600<=i<=20999 or 26600<=i<=26999 or 29600<=i<=29999 or 32600<=i<=32999 or 35600<=i<=35999: 
        return s+' '+ '-1'+'\n'
    else:
        return s+' '+ '1'+'\n'

# f = open('/mnt/usb/VOCdevkit_drone_ver/VOC2007/ImageSets/Main/train_train.txt', 'w')
f = open('/home/tim7107/drone/drone_trainval.txt', 'w')
f1 = open('/home/tim7107/drone/drone_train.txt', 'w')
f2 = open('/home/tim7107/drone/drone_val.txt','w')

for i in range(9000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(12000,21000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(24000,30000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
for i in range(30000,36000):
    temp = global_img_num(i)
    temp = determine(i,temp)
    f.write(temp)
    f2.write(temp)
    
f.close()
f1.close()
f2.close()