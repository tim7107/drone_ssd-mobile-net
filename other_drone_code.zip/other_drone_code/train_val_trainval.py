import numpy as np

def global_img_num(num):
    if num<10:
        return '00000'+str(num)+'\n'
    elif 10<=num<100:
        return '0000'+str(num)+'\n'
    elif 100<=num<1000:
        return '000'+str(num)+'\n'
    elif 1000<=num<10000:
        return '00'+str(num)+'\n'
    else:
        return '0'+str(num)+'\n'

def determine(i,s):
    if 2600<=i<=2999 or 5600<=i<=5999: 
        return s+' '+ '-1'+'\n'
    else:
        return s+' '+ '1'+'\n'

# f = open('/mnt/usb/VOCdevkit_drone_ver/VOC2007/ImageSets/Main/train_train.txt', 'w')
f = open('/home/tim7107/pascal_drone/VOCdevkit/VOC2007/ImageSets/Main/trainval.txt', 'w')
f1 = open('/home/tim7107/pascal_drone/VOCdevkit/VOC2007/ImageSets/Main/train.txt', 'w')
f2 = open('/home/tim7107/pascal_drone/VOCdevkit/VOC2007/ImageSets/Main/val.txt','w')

for i in range(3000):
    temp = global_img_num(i)
    # temp = determine(i,temp)
    f.write(temp)
    f1.write(temp)
    
for i in range(3000,6000):
    temp = global_img_num(i)
    # temp = determine(i,temp)
    f.write(temp)
    f2.write(temp)    
# for i in range(12000,21000):
    # temp = global_img_num(i)
    # temp = determine(i,temp)
    # f.write(temp)
    # f1.write(temp)
# for i in range(24000,30000):
    # temp = global_img_num(i)
    # temp = determine(i,temp)
    # f.write(temp)
    # f1.write(temp)
# for i in range(30000,36000):
    # temp = global_img_num(i)
    # temp = determine(i,temp)
    # f.write(temp)
    # f2.write(temp)
    
f.close()
f1.close()
f2.close()