import numpy as np
import cv2
print('v2')
frame_ = []
x_center = []
y_center = []
radius = 50
bbox = []
v1_with_drone=[]
v1_without_drone=[]
def data(temp):
    frame_.append(temp[0])
    x_center.append(temp[1])
    y_center.append(temp[2])

def decode_bbox(img,index,radius):
    i1 = x_center[index]-radius
    i2 = y_center[index]+radius
    i3 = x_center[index]+radius
    i4 = y_center[index]-radius
    if i1<=0 or i2<=0 or i3>1920 or i4>1080 or x_center[index]==0 or y_center[index]==0:
        v1_without_drone.append(index)
    else:
        v1_with_drone.append(index)
    bbox.append((i1,i2,i3,i4))
    
    
#----read text----#
f = open('/home/tim7107/drone/drone-tracking-datasets/dataset1/detections/cam2.txt', 'r')
lines = f.readlines() 
for line in lines:
    temp =[]
    for word in line.split(): 
        temp.append(int(float(word)))
    data(temp)
f.close() 

frame_ = np.array(frame_)
x_center = np.array(x_center)
y_center = np.array(y_center)

#----display video----#
cap = cv2.VideoCapture("/home/tim7107/drone/drone-tracking-datasets/dataset0/cam2.mp4")
index = 0
while(True):
    #print(index)
    ret, frame = cap.read()
    #frame = cv2.rotate(frame, cv2.ROTATE_180)
    decode_bbox(frame,index,radius)
    
    cv2.rectangle(frame,(x_center[index]-radius,y_center[index]-radius),(x_center[index]+radius,y_center[index]+radius),(0,255,0),3)
    #cv2.imshow('frame',frame)
    #if cv2.waitKey(1) & 0xFF == ord('q'):
    #    break
    index+=1
    if index == len(frame_):
        break
print(index)
#cap.release()
#cv2.destroyAllWindows()

bbox = np.array(bbox)
v1_without_drone = np.array(v1_without_drone)
v1_with_drone = np.array(v1_with_drone)
np.save('/home/tim7107/drone/drone-tracking-datasets/decode/determine_drone/v2_without_drone.npy', v1_without_drone)
np.save('/home/tim7107/drone/drone-tracking-datasets/decode/determine_drone/v2_with_drone.npy', v1_with_drone)
# np.save('/home/tim7107/drone/drone-tracking-datasets/decode/bbox_v2.npy', bbox)