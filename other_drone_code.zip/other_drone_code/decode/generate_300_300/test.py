import cv2
import numpy as np
import os 
import random
frame_ = []
x_center = []
y_center = []
radius = 10
def data(temp):
    frame_.append(temp[0])
    x_center.append(temp[1])
    y_center.append(temp[2])
    
#----read text----#
f = open('/home/tim7107/drone/drone-tracking-datasets/dataset3/detections/cam2.txt', 'r')
lines = f.readlines() 
for line in lines:
    temp =[]
    for word in line.split(): 
        temp.append(int(float(word)))
    data(temp)
f.close() 

frame_ = np.array(frame_)
x_center = np.array(x_center)
y_center = np.array(y_center)

with_drone = np.load('/home/tim7107/drone/drone-tracking-datasets/decode/npy_determine_drone/v10_with_drone.npy')
no_drone = np.load('/home/tim7107/drone/drone-tracking-datasets/decode/npy_determine_drone/v10_without_drone.npy')
it = random.choice(with_drone)
print(len(with_drone)+len(no_drone))
# it = 33546
temp = str(it) + '.jpg'
pth = os.path.join("/mnt/usb/drone_img/video10",temp)
img = cv2.imread(pth)
print(img.shape)
cv2.rectangle(img,(x_center[it]-radius,y_center[it]-radius),(x_center[it]+radius,y_center[it]+radius),(0,255,0),3)
cv2.imshow('frame',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
