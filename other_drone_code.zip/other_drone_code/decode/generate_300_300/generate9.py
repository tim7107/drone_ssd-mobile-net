import numpy as np
import cv2
import random
import os

#----Setting----#
video = 'v9'
video_ = 'video9'
radius = 15
mnt_video = os.path.join("/mnt/usb/drone_img/",video_)
img_no_drone_pth = os.path.join(mnt_video,'1.jpg')
detection_pth = '/home/tim7107/drone/drone-tracking-datasets/dataset3/detections/cam1.txt'
num = 27000

wd = video + '_with_drone.npy'
wod = video + '_without_drone.npy'
bb = video + '_bbox.npy'
c = video + '_xy_center.npy'

with_drone_pth = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/determine_drone',wd)

save_wd_pth = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/frameindex',wd)
save_wod_pth = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/frameindex',wod)
save_300_300_img_pth = os.path.join('/mnt/usb/drone_300_300/',video_)
save_300_300_bbox_pth = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/bbox_300_300/',bb)
save_300_300_xy_center = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/xy_center_300_300',c)
frame_ = []
x_center = []
y_center = []
valid_bd = 300-radius
new_bbox = []
new_center=[]
#---load detection(x_center,y_center)---#
def data(temp):
    frame_.append(temp[0])
    x_center.append(temp[1])
    y_center.append(temp[2])
    
def load_detection():
    f = open(detection_pth, 'r')
    lines = f.readlines() 
    for line in lines:
        temp =[]
        for word in line.split(): 
            temp.append(int(float(word)))
        data(temp)
    f.close()
    
def is_valid(i,valid_bd):
    if x_center[i]<valid_bd or x_center[i]>1920-valid_bd or y_center[i]<275 or y_center[i]>1080-valid_bd:
        return 1
    else:
        return 0

def save_img_filename(num):
    if num<10:
        return '00000'+str(num)+'.jpg'
    elif 10<=num<100:
        return '0000'+str(num)+'.jpg'
    elif 100<=num<1000:
        return '000'+str(num)+'.jpg'
    elif 1000<=num<10000:
        return '00'+str(num)+'.jpg'
    else:
        return '0'+str(num)+'.jpg'


load_detection()
frame_ = np.array(frame_)
x_center = np.array(x_center)
y_center = np.array(y_center)

#---------------------random 300*300 with drone-------------------------#
"""--------------------------
    detection : (5334,4)
                frame 0~5333
    random_drone_frame : 
                240
    random_no_drone_frame:
                60
--------------------------"""
# bbox = np.load('/home/tim7107/drone/drone-tracking-datasets/decode/bbox_v0.npy')
# print(bbox.shape)
with_drone = np.load('/home/tim7107/drone/drone-tracking-datasets/decode/npy_determine_drone/v9_with_drone.npy')
random_drone_frame = np.array(random.choices(with_drone,k=260))
for i in random_drone_frame:
    valid = is_valid(i,valid_bd)
    if valid == 1:
        flag = 1
        while(flag==1):
            new_i = random.choice(random_drone_frame)
            new_valid = is_valid(new_i,valid_bd)
            flag = 0 if new_valid==0 else 1
        for j in range(len(random_drone_frame)):
            if random_drone_frame[j] == i:
                random_drone_frame[j] = new_i 
for i in random_drone_frame:
    count = 0
    temp = str(i)+'.jpg'
    img = cv2.imread(os.path.join(mnt_video,temp))
    cv2.imwrite('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/test1/test.jpg', img)
    while(count<10):
        generate_upleft_x = random.randint(x_center[i]-(130-radius),x_center[i]+(130-radius))-150
        generate_upleft_y = random.randint(y_center[i]-(130-radius),y_center[i]+(130-radius))-150
        if generate_upleft_x<0 or generate_upleft_x>1920 or generate_upleft_y<0 or generate_upleft_y>1080:
            print('continue')
            continue            
        else:
            #---new bd---#
            nc_x,nc_y = x_center[i]-generate_upleft_x,y_center[i]-generate_upleft_y
            ul_x,ul_y = nc_x-radius, nc_y-radius
            br_x,br_y = nc_x+radius, nc_y+radius
            new_bbox.append((ul_x,ul_y,br_x,br_y))
            new_center.append((nc_x,nc_y))
            #---new img---#
            assign_img_file_name = save_img_filename(num)
            each_save_300_300_img_pth = os.path.join(save_300_300_img_pth,assign_img_file_name)
            crop_img = img[generate_upleft_y:generate_upleft_y+300,generate_upleft_x:generate_upleft_x+300]
            cv2.imwrite(each_save_300_300_img_pth, crop_img)
            # cv2.imwrite(os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/test/',assign_img_file_name),crop_img)
        count+=1
        num+=1
        print(num)

#---------------------random 300*300 without drone-------------------------#
img_no_dorne = cv2.imread(img_no_drone_pth)
for i in range(400):
    nd_generate_ul_x = random.randint(0,1600)
    nd_generate_ul_y = random.randint(0,700)
    assign_img_file_name = save_img_filename(num)
    each_save_300_300_img_pth = os.path.join(save_300_300_img_pth,assign_img_file_name)
    nd_crop_img = img_no_dorne[nd_generate_ul_y:nd_generate_ul_y+300,nd_generate_ul_x:nd_generate_ul_x+300]
    cv2.imwrite(each_save_300_300_img_pth, nd_crop_img)
    # cv2.imwrite(os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/test/',assign_img_file_name),nd_crop_img)
    num+=1
    print(num)

random_drone_frame = np.array(random_drone_frame)
new_bbox = np.array(new_bbox)
new_center = np.array(new_center)
print('len of random_drone_frame ',random_drone_frame.shape)
print('shape of bbox ', new_bbox.shape)
print('shape of center ', new_center.shape)

# np.save('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/test/frame.npy',np.array(random_drone_frame))
# np.save('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/test/box.npy',np.array(new_bbox))
# np.save('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/test/center.npy',np.array(new_center))
np.save(save_wd_pth,random_drone_frame)
np.save(save_300_300_bbox_pth,new_bbox)
np.save(save_300_300_xy_center,new_center)