import os
import cv2
import numpy as np
import random
"""
   0~2599 drone
   2600~2999 no drone
"""
def img_tmp(num):
    if num<10:
        return '00000'+str(num)+'.jpg'
    elif 10<=num<100:
        return '0000'+str(num)+'.jpg'
    elif 100<=num<1000:
        return '000'+str(num)+'.jpg'
    elif 1000<=num<10000:
        return '00'+str(num)+'.jpg'
    else:
        return '0'+str(num)+'.jpg'
        
v = 10
v_ = 'video' + str(v)
bbox_temp = 'v' + str(v) + '_bbox.npy'
bbox_pth = os.path.join('/home/tim7107/drone/drone-tracking-datasets/decode/generate_300_300/bbox_300_300/',bbox_temp)
img_random = random.randint(v*3000,v*3000+2599)
img_temp = img_tmp(img_random)
img_pth = os.path.join('/mnt/usb/drone_300_300',v_,img_temp)
bbox = np.load(bbox_pth)
img = cv2.imread(img_pth)

#---check first and last---#
fist_pth = os.path.join('/mnt/usb/drone_300_300',v_,('0'+str(3000*v)+'.jpg'))
last_pth = os.path.join('/mnt/usb/drone_300_300',v_,('0'+str(3000*v+2599)+'.jpg'))
print(fist_pth)
print(last_pth)
first_img = cv2.imread(fist_pth)
last_img = cv2.imread(last_pth)
if len(first_img[0])>0:
    print('yes')
else:
    print('no')
    
if len(last_img[0])>0:
    print('yes')
else:
    print('no')  
 
# cv2.rotate(img, cv2.ROTATE_180)
#----show random----#
print('choose frame :',img_random)
x = img_random - v*3000
cv2.rectangle(img,(bbox[x][0],bbox[x][1]),(bbox[x][2],bbox[x][3]),(0,255,0),3)
cv2.imshow('frame',img)
cv2.waitKey(0)
cv2.destroyAllWindows()